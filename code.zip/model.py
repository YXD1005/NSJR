import torch
import numpy as np, torch.nn as nn, torch.nn.functional as F
import math
from Transformer_Encoder import Rule_Transformer
import data
from layers import MLP, FuncToNodeSum_StructContextFusion
from gnn import GlobalLayer, CompLayer, NodeLayer, EdgeLayer

from utils import get_param


class MultiHeadAttention(nn.Module):
    ''' Multi-Head Attention module '''

    def __init__(self, n_head, d_model, d_k, d_v, **kwargs):
        super().__init__()

        self.n_head = n_head
        self.d_k = d_k
        self.d_v = d_v

        self.w_qs = nn.Linear(d_model, n_head * d_k)
        self.w_ks = nn.Linear(d_model, n_head * d_k)
        self.w_vs = nn.Linear(d_model, n_head * d_v)
        nn.init.normal_(self.w_qs.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_k)))
        nn.init.normal_(self.w_ks.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_k)))
        nn.init.normal_(self.w_vs.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_v)))

        self.attention = ScaledDotProductAttention(temperature=np.power(d_k, 0.5),
                                                   dropout=kwargs['dr_sdp'])
        self.layer_norm = nn.LayerNorm(d_model)
        self.layer_norm_in = nn.LayerNorm((3, n_head * d_v))

        self.fc = nn.Linear(n_head * d_v, d_model)
        nn.init.xavier_normal_(self.fc.weight)

        self.dropout = nn.Dropout(kwargs['dr_mha'])

    def forward(self, q, k, v, mask=None):
        d_k, d_v, n_head = self.d_k, self.d_v, self.n_head

        sz_b, len_q, _ = q.size()
        sz_b, len_k, _ = k.size()
        sz_b, len_v, _ = v.size()

        residual = q

        q = self.w_qs(q).view(sz_b, len_q, n_head, d_k)
        k = self.w_ks(k).view(sz_b, len_k, n_head, d_k)
        v = self.w_vs(v).view(sz_b, len_v, n_head, d_v)

        q = q.transpose(1, 2).contiguous().view(-1, len_q, d_k)  # (n*b) x lq x dk
        k = k.transpose(1, 2).contiguous().view(-1, len_k, d_k)  # (n*b) x lk x dk
        v = v.transpose(1, 2).contiguous().view(-1, len_v, d_v)  # (n*b) x lv x dv

        output = self.attention(q, k, v)

        output = output.view(sz_b, n_head, len_q, d_v)
        output = output.transpose(1, 2).contiguous().view(sz_b, len_q, -1)  # b x lq x (n*dv)

        output = self.dropout(self.fc(output))
        output = self.layer_norm(output + residual)

        return output


class ScaledDotProductAttention(nn.Module):
    ''' Scaled Dot-Product Attention '''

    def __init__(self, temperature, dropout=0.2):
        super().__init__()
        self.temperature = temperature
        self.dropout = nn.Dropout(dropout)
        self.softmax = nn.Softmax(dim=2)

    def forward(self, q, k, v):
        attn = torch.bmm(q, k.transpose(1, 2))
        attn = attn / self.temperature

        attn = self.softmax(attn)
        attn = self.dropout(attn)
        output = torch.bmm(attn, v)

        return output


class PositionwiseFeedForwardUseConv(nn.Module):
    def __init__(self, d_in, d_hid, dropout=0.3, decode_method='twomult'):
        super(PositionwiseFeedForwardUseConv, self).__init__()
        self.w_1 = nn.Conv1d(d_in, d_hid, 1)
        nn.init.kaiming_uniform_(self.w_1.weight, mode='fan_out', nonlinearity='relu')
        self.w_2 = nn.Conv1d(d_hid, d_in, 1)
        nn.init.kaiming_uniform_(self.w_2.weight, mode='fan_in', nonlinearity='relu')
        self.layer_norm = nn.LayerNorm(d_in)
        self.dropout = nn.Dropout(dropout)
        self.decode_method = decode_method

    def forward(self, x):
        residual = x
        output = x.transpose(1, 2)
        output = self.w_2(F.relu(self.w_1(output)))
        output = output.transpose(1, 2)
        output = self.dropout(output)
        if self.decode_method == 'tucker':
            output = output + residual
        else:
            output = self.layer_norm(output + residual)
        return output


class EncoderLayer(nn.Module):
    def __init__(self, d_model, d_inner, n_head, d_k, d_v, **kwargs):
        super(EncoderLayer, self).__init__()
        self.slf_attn = MultiHeadAttention(
            n_head, d_model, d_k, d_v, **kwargs)
        self.pos_ffn = PositionwiseFeedForwardUseConv(
            d_model, d_inner, dropout=kwargs['dr_pff'],
            decode_method=kwargs['decoder'])

    def forward(self, enc_input):
        enc_output = self.slf_attn(enc_input, enc_input, enc_input)
        enc_output = self.pos_ffn(enc_output)

        return enc_output


class Encoder(nn.Module):
    def __init__(self, d_input, n_layers, n_head, d_k, d_v,
                 d_model, d_inner, **kwargs):
        super(Encoder, self).__init__()
        # parameters
        self.d_input = d_input
        self.n_layers = n_layers
        self.n_head = n_head
        self.d_k = d_k
        self.d_v = d_v
        self.d_model = d_model
        self.d_inner = d_inner
        self.linear_in = nn.Linear(d_input, d_model)
        self.layer_norm_in = nn.LayerNorm(d_model)
        self.bn = nn.BatchNorm2d(1)
        self.dropout = nn.Dropout(kwargs['dr_enc'])

        self.layer_stack = nn.ModuleList([
            EncoderLayer(d_model, d_inner, n_head, d_k, d_v, **kwargs)
            for _ in range(n_layers)])

    def forward(self, edges):
        enc_output = self.dropout(edges)

        for enc_layer in self.layer_stack:
            enc_output = enc_layer(enc_output)

        return enc_output


class CRSF(nn.Module):  # rule sequence encoding layer
    def __init__(self, args, num_nodes, num_rels):
        super().__init__()
        self.n_ent = num_nodes
        self.n_rel = num_rels
        self.padding_index = self.n_rel * 2
        self.rule_hidden_dim = args.rule_hidden_dim
        self.rule_dim = args.rule_dim
        self.rule_len = args.rule_len
        self.num_head = 2
        self.num_encoder = args.num_encoder
        self.comp_op = args.comp_op
        self.h_dim = args.h_dim
        assert self.comp_op in ['add', 'mul']

        self.fc_R = nn.Linear(self.rule_dim, self.h_dim)
        self.fc1 = nn.Linear(self.h_dim * self.rule_len, self.rule_dim)

        # rule transformer
        self.rule_transformer = Rule_Transformer(self.h_dim, self.rule_hidden_dim, self.rule_dim, self.rule_len,
                                                 self.num_head, self.num_encoder, args.rule_drop)

    def forward(self, rules, rules_mask, IM, rel_emb):
        rule_body = rules[:, 2:]  # torch.Size([rules_num, 3])
        body_embs = rel_emb[rule_body]  # torch.Size([rules_num, 3, h_dim])
        # rule head
        rule_head = rules[:, 1]  # torch.Size([rules_num])
        head_embs = rel_emb[rule_head]  # torch.Size([rules_num, h_dim])
        head_embs = head_embs.unsqueeze(1)  # torch.Size([rules_num, 1, h_dim])

        # rule body transformer
        rules_mask = rules_mask.unsqueeze(1)  # torch.Size([rules_num, 1, 3])
        body_embs = self.rule_transformer(body_embs, head_embs, rules_mask)
        # [rules_num, h_dim]

        dva_i = 1 / IM.sum(0)
        dva_i[torch.isinf(dva_i)] = 0.0
        IM = IM.transpose(0, 1)  # torch.Size([n_rel*2, rules_num])
        pred_rel_emb = IM @ body_embs * dva_i[:, None]
        pred_rel_emb = F.relu(self.fc_R(pred_rel_emb))

        return pred_rel_emb, body_embs.detach()


class RENR(nn.Module):

    def __init__(
            self, args,
            graph,
            kg,
            Ht,
            num_nodes,
            num_rels,
            n_layers,
            d_embd,
            d_k,
            d_v,
            d_model,
            d_inner,
            n_head,
            h_dim,
            **kwargs
    ):
        super(RENR, self).__init__()
        self.n_ent = num_nodes
        self.n_rel = num_rels
        self.encoder = Encoder(d_embd, n_layers, n_head, d_k, d_v, d_model, d_inner, **kwargs)
        self.decoder = Encoder(d_embd, n_layers, n_head, d_k, d_v, d_model, d_inner, **kwargs)
        self.hr_encoder = Encoder(d_embd, n_layers, n_head, d_k, d_v, d_model, d_inner, **kwargs)
        self.hR_encoder = Encoder(d_embd, n_layers, n_head, d_k, d_v, d_model, d_inner, **kwargs)
        self.rR_encoder = Encoder(d_embd, n_layers, n_head, d_k, d_v, d_model, d_inner, **kwargs)
        self.register_parameter('b', nn.Parameter(torch.zeros(num_nodes)))
        self.graph = graph
        self.d_embd = d_embd
        self.init_parameters()
        self.ent_bn = nn.LayerNorm(d_embd)
        self.rel_bn = nn.LayerNorm(d_embd)
        self.rule_bn = nn.LayerNorm(d_embd)
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.rule_layer = CRSF(args, num_nodes, num_rels)
        self.r_rel_emb = data.get_param(self.n_rel * 2 + 1, h_dim)
        self.path_dim = self.d_embd
        self.args = args
        self.kg_n_layer = args.kg_n_layer
        self.kg = kg
        self.ht = Ht
        # relation SE layer
        self.edge_layers = nn.ModuleList([EdgeLayer(h_dim) for _ in range(self.kg_n_layer)])
        # entity SE layer
        self.node_layers = nn.ModuleList([NodeLayer(h_dim) for _ in range(self.kg_n_layer)])
        # triple SE layer
        self.comp_layers = nn.ModuleList([CompLayer(h_dim) for _ in range(self.kg_n_layer)])
        self.pred_rel_emb = get_param(self.n_rel * 2 + 1, h_dim)
        self.global_layer = GlobalLayer(h_dim)
        self.rel_embs = nn.ParameterList([get_param(self.n_rel * 2 + 1, h_dim) for _ in range(self.kg_n_layer)])
        self.rel_w = get_param(h_dim * self.kg_n_layer, h_dim)
        self.body_embs = None

    def init_parameters(self):
        self.tr_ent_embedding = nn.Parameter(torch.Tensor(self.n_ent, self.d_embd))
        self.tr_ent_embedding1 = nn.Parameter(torch.Tensor(self.n_ent, self.d_embd))
        nn.init.xavier_normal_(self.tr_ent_embedding1.data)
        self.rel_embedding = nn.Parameter(torch.Tensor(2 * self.n_rel, self.d_embd))
        nn.init.xavier_normal_(self.tr_ent_embedding.data)
        nn.init.xavier_normal_(self.rel_embedding.data)

    def aggragate_emb(self, kg, Ht, R):
        ent_emb = self.tr_ent_embedding
        rel_emb_list = []
        for edge_layer, node_layer, comp_layer, rel_emb in zip(self.edge_layers, self.node_layers, self.comp_layers,
                                                               self.rel_embs):
            rel_emb = rel_emb[:-1, :] + R
            rel_emb = torch.cat([rel_emb, self.rel_embs[0][-1:, :]], dim=0)
            edge_ent_emb = edge_layer(kg, ent_emb, rel_emb)
            node_ent_emb = node_layer(kg, ent_emb)
            comp_ent_emb = comp_layer(kg, ent_emb, rel_emb)
            ent_emb = ent_emb + edge_ent_emb + node_ent_emb + comp_ent_emb
            rel_emb_list.append(rel_emb)

        pred_rel_emb = torch.cat(rel_emb_list, dim=1)
        pred_rel_emb = pred_rel_emb.mm(self.rel_w)

        # pred_rel_emb = self.pred_rel_emb
        g_ent_emb = self.global_layer(Ht, self.tr_ent_embedding1)
        rel_emb = pred_rel_emb[:-1, :]
        ent_emb = ent_emb + g_ent_emb
        return ent_emb, rel_emb

    def cal_score(self, edges, rules, rules_mask, IM):
        h = self.tr_ent_embedding[edges[:, 0]]
        r = self.rel_embedding[edges[:, 1]]
        h = self.ent_bn(h)[:, None]
        r = self.rel_bn(r)[:, None]

        rule_rel_emb, body_embs = self.rule_layer(rules, rules_mask, IM, self.r_rel_emb)
        self.body_embs = body_embs
        relation_indices = edges[:, 1]  # (batch_size,)
        r_rule_batch = rule_rel_emb[relation_indices]  # (batch_size, 100)
        R = self.rule_bn(r_rule_batch)[:, None]

        hr = torch.hstack((h, r))  # [B, 2, d_embd]
        hr = self.hr_encoder(hr)

        ent_emb, rel_emb = self.aggragate_emb(self.kg, self.ht, rule_rel_emb)
        head = ent_emb[edges[:, 0]][:, None]
        rel = rel_emb[edges[:, 1]][:, None]
        hR = torch.hstack((head, rel))  # [B, 2, d_embd]
        hR = self.hR_encoder(hR)

        rR = torch.hstack((r, R))  # [B, 2, d_embd]
        rR = self.rR_encoder(rR)

        feat_edges = hr + rR + hR
        embd_edges = self.decoder(feat_edges)
        src_edges = embd_edges[:, 1, :]
        # src_edges = embd_edges[:, 1, :] + hR[:, 1, :]
        scores = torch.mm(src_edges, self.tr_ent_embedding.transpose(0, 1))
        scores += self.b.expand_as(scores)
        return scores

    def predict(self, edges, rules, rules_mask, IM):
        labels = edges[:, 2]
        edges = edges[0][None, :]
        scores = self.cal_score(edges, rules, rules_mask, IM)
        scores = scores[:, labels.view(-1)].view(-1)
        scores = torch.sigmoid(scores)
        acc = 0.0
        return scores, acc


class SimpleDecoderTransformer(nn.Module):
    def __init__(self, dim, num_layers=2, nhead=4):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(d_model=dim, nhead=nhead, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, h_emb, r_emb, entity_emb):
        x = torch.stack([h_emb, r_emb], dim=1)  # [B, 2, D]
        x = self.transformer(x)  # [B, 2, D]
        cls_emb = x[:, 0]  # [B, D]
        score = self.out_proj(cls_emb) @ entity_emb.T  # [B, E]
        return score


class CASR(nn.Module):

    def __init__(
            self,
            args,
            graph,
            num_nodes,
            num_rels,
            rules
    ):
        super(CASR, self).__init__()

        self.graph = graph
        self.num_nodes = num_nodes
        self.num_rels = num_rels
        dataset = args.dataset
        self.max_length = max([len(rule[2:]) for rule in rules])
        self.mlp_rule_dim = args.mlp_rule_dim
        self.rule_to_entity = FuncToNodeSum_StructContextFusion(self.mlp_rule_dim, self.mlp_rule_dim)

        if "FB15k-237" in dataset or "wn18rr" in dataset:
            self.score_model = MLP(self.mlp_rule_dim, [128, 1])
        else:
            self.score_model = MLP(self.mlp_rule_dim, [1])
        self.bias = torch.nn.parameter.Parameter(torch.zeros(self.num_nodes))

        self.num_rules = len(rules)
        self.decoder = SimpleDecoderTransformer(
            dim=self.mlp_rule_dim,  # 和你的 entity/relation embedding 维度一致
            num_layers=2,
            nhead=2
        )

        self.relation2rules = [[] for r in range(self.num_rels * 2)]
        for rule in rules:
            relation = rule[1]
            self.relation2rules[relation].append([rule[0], (rule[1], rule[2:])])

        self.mlp_feature = nn.Parameter(torch.zeros(self.num_rules, self.mlp_rule_dim))
        nn.init.kaiming_uniform_(self.mlp_feature, a=math.sqrt(5), mode="fan_in")
        self.rule_emb = torch.nn.Embedding(self.num_rules, self.mlp_rule_dim)
        nn.init.kaiming_uniform_(self.rule_emb.weight, a=math.sqrt(5), mode="fan_in")
        self.entity_embedding = torch.nn.Embedding(num_nodes, self.mlp_rule_dim)
        nn.init.kaiming_uniform_(self.entity_embedding.weight, a=math.sqrt(5), mode="fan_in")
        self.relation_embedding = torch.nn.Embedding(num_rels * 2, self.mlp_rule_dim)
        nn.init.kaiming_uniform_(self.relation_embedding.weight, a=math.sqrt(5), mode="fan_in")

        self.rules_weight_emb = None

    def cal_rule_score(self, all_h, all_r, edges_to_remove, model1):
        query_r = all_r[0].item()
        assert (all_r != query_r).sum() == 0
        device = all_r.device
        B = all_h.size(0)

        rule_index = []
        rule_count = []
        mask = torch.zeros(B, self.graph.entity_size, device=device)

        for index, (r_head, r_body) in self.relation2rules[query_r]:
            assert r_head == query_r
            count = self.graph.grounding(all_h, r_head, r_body, edges_to_remove).float()  # [B, E]
            mask += count
            rule_index.append(index)
            rule_count.append(count)

        if mask.sum().item() == 0:
            return mask + self.bias.unsqueeze(0), (1 - mask).bool()

        candidate_set = torch.nonzero(mask.view(-1), as_tuple=True)[0]  # [B*E']

        rule_index = torch.tensor(rule_index, dtype=torch.long, device=device)  # [R]
        rule_count = torch.stack(rule_count, dim=0)  # [R, B, E]
        rule_count = rule_count.reshape(rule_index.size(0), -1)[:, candidate_set]  # [R, B*E']

        rule_emb = self.rule_emb(rule_index)  # [R, D]
        mlp_feature = self.mlp_feature[rule_index]  # [R, D, 1]
        h_emb = self.entity_embedding(all_h)  # [B, D]
        r_emb = self.relation_embedding(all_r)  # [B, D]

        output = self.rule_to_entity(
            rule_count, h_emb, r_emb, rule_emb, mlp_feature
        )  # [B*E', D]
        # output = self.rule_to_entity(rule_count, rule_emb, mlp_feature)

        output = self.score_model(output).squeeze(-1)  # [B*E']

        score = torch.zeros(B * self.graph.entity_size, dtype=output.dtype, device=device)
        score.scatter_(0, candidate_set, output)  # [B * E]
        score = score.view(B, self.graph.entity_size)  # [B, E]
        score = score + self.bias.unsqueeze(0)  # [B, E]

        decoder_score = self.decoder(h_emb, r_emb, self.entity_embedding.weight)  # [B, E]
        final_score = score + decoder_score
        mask = torch.ones_like(mask).bool()

        return final_score, mask

    def predict_rule(self, edges, edges_to_remove):
        labels = edges[:, 2]
        edges = edges[0][None, :]
        all_h = edges[:, 0]
        all_r = edges[:, 1]
        scores, _ = self.cal_rule_score(all_h, all_r, edges_to_remove)
        scores = scores[:, labels.view(-1)].view(-1)
        scores = torch.sigmoid(scores)
        acc = 0.0
        return scores, acc
