import numpy as np
import torch
from torch.optim.lr_scheduler import ExponentialLR, StepLR
from utils import  calc_mrr1, calc_rule_mrr1, calc_rule_mrr2
import numpy as np, torch.nn as nn, torch.nn.functional as F
import random
from torch.utils.data import DataLoader
from itertools import islice
import torch, random, os, logging
from tqdm import tqdm


class PreTrainer(object):

    def __init__(self, model, train_set, valid_set, test_set, ruleset):

        self.model = model.cuda()
        self.train_set = train_set
        self.valid_set = valid_set
        self.test_set = test_set
        self.ruleset = ruleset
        self.rules = ruleset.R.cuda()
        self.rules_mask = ruleset.R_mask.cuda()
        self.IM = ruleset.IM.cuda()

        self.loss = torch.nn.BCELoss()

    def train(self, args, logger, names2ids, rels2ids, model_state_file):
        loss1 = nn.BCELoss()
        model = self.model
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
        scheduler = StepLR(optimizer, step_size=args.lr_step_decay, gamma=args.lr_decay)

        logger.info(f'num entities: {len(names2ids)}, num relations: {len(rels2ids)}')

        best_mrr = 0
        best_epoch = 0
        for epoch in range(1, args.n_epochs + 1):
            model.train()

            for edges in self.train_set:
                edges = torch.as_tensor(edges, dtype=torch.long).cuda()
                rules = self.rules
                rules_mask = self.rules_mask
                IM = self.IM
                scores = model.cal_score(edges, rules, rules_mask, IM)

                labels = torch.zeros_like(scores).cuda()
                labels.scatter_(1, edges[:, 2][:, None], 1.)
                if args.label_smoothing:
                    labels = ((1.0 - args.label_smoothing) * labels) + (1.0 / labels.size(1))
                loss = F.binary_cross_entropy_with_logits(scores, labels)
                # loss = self.loss(scores, labels)
                loss = loss + 0.1
                loss.backward()

                optimizer.step()
                optimizer.zero_grad()

            if epoch <= args.decay_until:
                scheduler.step()
            if epoch % 10 == 0:
                logger.info(f'Epoch {epoch:04d} | Loss {loss.item():.7f}| Best MRR {best_mrr:.4f}')
            if epoch >= args.start_test_at and epoch % 10 == 0:
                best_mrr = self.valid(logger, best_mrr, epoch, loss, model_state_file)

    def valid(self, logger, best_mrr, epoch, loss, model_state_file):
        model = self.model

        valid_loader = DataLoader(self.test_set, batch_size=1)
        with torch.no_grad():
            model.eval()
            logger.info('start eval')

            mrr = calc_mrr1(model, valid_loader,
                            self.rules, self.rules_mask, self.IM, logger=logger)
            
            if best_mrr < mrr:
                best_mrr = mrr

                logger.info(
                    f'Epoch {epoch:04d} | Loss {loss.item():.7f} | Best MRR {best_mrr:.4f} | Best epoch {epoch:04d}')
                torch.save(model.state_dict(), model_state_file)

            logger.info('eval done!')
        return best_mrr

    def test(self, logger, checkpoint):
        model = self.model
        valid_loader = DataLoader(self.test_set, batch_size=1, shuffle=False)
        model.load_state_dict(checkpoint)
        with torch.no_grad():
            model.eval()
            logger.info('start eval')
            mrr1 = calc_mrr1(model, valid_loader,
                             self.rules, self.rules_mask, self.IM, logger=logger)
            logger.info('test done!')


class GroundTrainer(object):

    def __init__(self, model, model1, train_set, valid_set, test_set, ruleset):

        self.model = model.cuda()
        self.model1 = model1
        self.model1 = model1.cuda()
        self.train_set = train_set
        self.valid_set = valid_set
        self.test_set = test_set
        self.ruleset = ruleset
        self.rules = ruleset.R.cuda()
        self.rules_mask = ruleset.R_mask.cuda()
        self.IM = ruleset.IM.cuda()
        self.body_embs = model1.body_embs

    def train(self, args, logger, model_state_file):

        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            lr=float(args.g_lr),
            weight_decay=float(args.weight_decay))
        self.train_set.make_batches()
        train_dataloader = DataLoader(self.train_set, 1, num_workers=10)

        best_mrr = 0
        best_epoch = 0
        batch_per_epoch = 1000000000
        for epoch in range(1, args.num_iters + 1):

            logger.info('-------------------------')
            logger.info('| Iteration: {}/{}'.format(epoch, args.num_iters))
            logger.info('-------------------------')
            batch_per_epoch = batch_per_epoch or len(train_dataloader)
            model = self.model
            model1 = self.model1

            model.train()
            total_loss = 0.0
            total_size = 0.0

            for batch_id, batch in enumerate(islice(train_dataloader, batch_per_epoch)):
                all_h, all_r, all_t, target, edges_to_remove = batch
                all_h = all_h.squeeze(0)
                all_r = all_r.squeeze(0)
                all_t = all_t.squeeze(0)
                target = target.squeeze(0)
                edges_to_remove = edges_to_remove.squeeze(0)
                target_t = torch.nn.functional.one_hot(all_t, self.train_set.graph.entity_size)

                all_h = all_h.cuda()
                all_r = all_r.cuda()
                all_t = all_t.cuda()
                target = target.cuda()
                edges_to_remove = edges_to_remove.cuda()
                target_t = target_t.cuda()

                target = target * args.smoothing + target_t * (1 - args.smoothing)

                grounding_rule_score, mask = model.cal_rule_score(all_h, all_r, edges_to_remove,model1)

                if mask.sum().item() != 0:
                    rule_logits = (torch.softmax(grounding_rule_score, dim=1) + 1e-8).log()

                    loss = -(rule_logits[mask] * target[mask]).sum() / torch.clamp(target[mask].sum(), min=1)
                    loss.backward()

                    optimizer.step()
                    optimizer.zero_grad()

                    total_loss += loss.item()
                    total_size += mask.sum().item()

                if (batch_id + 1) % args.print_every == 0:
                    logger.info('loss:    {} {} {:.6f} {:.1f}'.format(batch_id + 1, len(train_dataloader), loss,
                                                                      total_size / args.print_every))
                    total_loss = 0.0
                    total_size = 0.0

            mrr = self.valid(logger)
            
            if best_mrr < mrr:
                best_mrr = mrr
                torch.save(model.state_dict(), model_state_file)
            logger.info(
                f'Epoch {epoch:04d} | Loss {loss.item():.7f} | Best MRR {best_mrr:.4f} ')

    def valid(self, logger):
        valid_loader = DataLoader(self.test_set, batch_size=1)
        model = self.model
        model1 = self.model1
        with torch.no_grad():
            model.eval()
            logger.info('start eval')
            mrr = calc_rule_mrr2(model, valid_loader, self.test_set,model1, logger)

            logger.info('eval done!')
        return mrr

    def test(self, args, logger, checkpoint1, checkpoint):
        valid_loader = DataLoader(self.test_set, batch_size=1)
        model = self.model
        model.load_state_dict(checkpoint1)
        model1 = self.model1
        model1.load_state_dict(checkpoint)
        model1 = self.model1
        with torch.no_grad():
            model.eval()
            logger.info('start eval')


            mrr1 = calc_rule_mrr1(args,model, model1, self.rules, self.rules_mask, self.IM, valid_loader, self.test_set,
                                   logger)
            # mrr = calc_rule_mrr2(model, valid_loader, self.test_set, logger)

            logger.info('test done!')
