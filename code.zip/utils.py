import torch, random, os, logging
import numpy as np
from numpy.random import RandomState
from tqdm import tqdm
import yaml
import easydict
import dgl
from torch.nn import Parameter
from torch.nn.init import xavier_normal_
from collections import defaultdict

def set_seed(seed):
    torch.manual_seed(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_config(cfg_file):
    # cfg_file = os.path.join(cfg_file, 'config.json')
    with open(cfg_file, "r") as fin:
        raw_text = fin.read()

    if "---" in raw_text:
        configs = []
        grid, template = raw_text.split("---")
        grid = yaml.safe_load(grid)
        template = jinja2.Template(template)
        for hyperparam in meshgrid(grid):
            config = easydict.EasyDict(yaml.safe_load(template.render(hyperparam)))
            configs.append(config)
    else:
        configs = [easydict.EasyDict(yaml.safe_load(raw_text))]

    return configs


def setup_logger(
        name,
        level=logging.DEBUG,
        stream_handler=True,
        file_handler=True,
        log_file='default.log'
):
    open(log_file, 'w').close()
    logger = logging.getLogger(name)
    logger.setLevel(level)
    formatter = logging.Formatter(
        fmt='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d,%H:%M:%S'
    )

    if stream_handler:
        sth = logging.StreamHandler()
        sth.setLevel(level)
        sth.setFormatter(formatter)
        logger.addHandler(sth)

    if file_handler:
        fh = logging.FileHandler(log_file)
        fh.setLevel(level)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger


def fix_seed(seed_value):
    torch.manual_seed(seed_value)
    random.seed(seed_value)
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)


def get_mappings(src_file_paths):
    names2ids = dict()
    rels2ids = dict()
    with open(os.path.join(src_file_paths, 'entities.dict')) as fi:
        for line in fi:
            id, entity = line.strip().split('\t')
            names2ids[entity] = int(id)

    with open(os.path.join(src_file_paths, 'relations.dict')) as fi:
        for line in fi:
            id, relation = line.strip().split('\t')
            rels2ids[relation] = int(id)
    return names2ids, rels2ids


def get_main_data(src_path, names2ids, rels2ids, add_inverse=False):
    with open(src_path, 'r') as file:
        file_lines = file.readlines()

    num_relations = len(rels2ids.keys())
    triples = []

    for line in file_lines:
        line = line.strip()
        src, rel, dst = line.split('\t')
        triples.append([names2ids[src], rels2ids[rel], names2ids[dst]])

    triples = np.array(triples)
    print(add_inverse)
    if add_inverse:
        inverse_triples = triples[:, [2, 1, 0]].copy()
        inverse_triples[:, 1] += num_relations
        triples = np.vstack((triples, inverse_triples))

    train_list = triples.tolist()

    # 拆分成头实体、关系和尾实体
    src_list = [item[0] for item in train_list]  # 获取每个三元组的头实体（第一列）
    rel_list = [item[1] for item in train_list]  # 获取每个三元组的关系（第二列）
    dst_list = [item[2] for item in train_list]

    return {
        'src_list': src_list,
        'dst_list': dst_list,
        'rel_list': rel_list,
        'total_unique_nodes': len(names2ids.keys()),
        'total_unique_rels': len(rels2ids.keys()),
        'names2ids': names2ids,
        'rels2ids': rels2ids,
        'triples': triples,
    }


def construct_kg(train_data, n_ent, num_rels):
    src_list, dst_list, rel_list = [], [], []

    eid = 0
    hr2eid, rt2eid = defaultdict(list), defaultdict(list)
    x = len(train_data['src_list']) // 2
    for h, t, r in zip(train_data['src_list'], train_data['dst_list'], train_data['rel_list']):
        src_list.extend([h])
        dst_list.extend([t])
        rel_list.extend([r])
        hr2eid[(h, r)].extend([eid])
        rt2eid[(r, t)].extend([eid])
        eid += 1

    src, dst, rel = torch.tensor(src_list), torch.tensor(dst_list), torch.tensor(rel_list)

    Ht = torch.zeros(n_ent, num_rels * 2).cuda()
    print("Max dst:", dst.max().item())
    print("Max rel:", rel.max().item())
    print("Ht shape:", Ht.shape)
    Ht[src, rel] = 1
    Ht[dst, rel] = 1
    # 创建DGL图
    kg = dgl.graph((src, dst), num_nodes=n_ent)
    kg.edata['rel_id'] = rel

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    kg = kg.to(device)

    return kg, Ht


def get_param(*shape):
    param = Parameter(torch.zeros(shape))
    xavier_normal_(param)
    return param


from torch.utils.data import Dataset



def get_main(data_dir, file_path, names2ids, rels2ids, add_inverse):
    data_path = os.path.join(data_dir, file_path)
    main_data = get_main_data(data_path, names2ids, rels2ids, add_inverse=add_inverse)
    return main_data


def calc_mrr1(model, valid_loader, rules, rules_mask, IM, logger=None):
    concat_logits = []
    concat_all_h = []
    concat_all_r = []
    concat_all_t = []
    concat_flag = []
    # concat_mask = []
    i = 0
    for batch in valid_loader:
        all_h, all_r, all_t, flag = batch
        all_h = all_h.squeeze(0).unsqueeze(1)
        all_r = all_r.squeeze(0).unsqueeze(1)
        all_t = all_t.squeeze(0).unsqueeze(1)
        flag = flag.squeeze(0)

        all_h = all_h.cuda()
        all_r = all_r.cuda()
        all_t = all_t.cuda()
        flag = flag.cuda()
        rules = rules.cuda()
        edges = torch.cat((all_h, all_r, all_t), dim=1).cuda()
        rules_mask = rules_mask.cuda()
        IM = IM.cuda()
        KGE_score = model.cal_score(edges, rules, rules_mask, IM)

        logits = KGE_score

        concat_logits.append(logits)
        concat_all_h.append(all_h)
        concat_all_r.append(all_r)
        concat_all_t.append(all_t)
        concat_flag.append(flag)

    concat_logits = torch.cat(concat_logits, dim=0)
    concat_all_h = torch.cat(concat_all_h, dim=0)
    concat_all_r = torch.cat(concat_all_r, dim=0)
    concat_all_t = torch.cat(concat_all_t, dim=0)
    concat_flag = torch.cat(concat_flag, dim=0)

    ranks = []
    for k in range(concat_all_t.size(0)):
        h = concat_all_h[k]
        r = concat_all_r[k]
        t = concat_all_t[k]
        val = concat_logits[k, t]

        L = (concat_logits[k][concat_flag[k]] > val).sum().item() + 1
        H = (concat_logits[k][concat_flag[k]] >= val).sum().item() + 2
        ranks += [[h, r, t, L, H]]
    ranks = torch.tensor(ranks, dtype=torch.long).cuda()

    query2LH = dict()
    for h, r, t, L, H in ranks.data.cpu().numpy().tolist():
        query2LH[(h, r, t)] = (L, H)
    expectation = True

    hit1, hit3, hit10, mr, mrr = 0.0, 0.0, 0.0, 0.0, 0.0
    for (L, H) in query2LH.values():
        if expectation:
            for rank in range(L, H):
                if rank <= 1:
                    hit1 += 1.0 / (H - L)
                if rank <= 3:
                    hit3 += 1.0 / (H - L)
                if rank <= 10:
                    hit10 += 1.0 / (H - L)
                mr += rank / (H - L)
                mrr += 1.0 / rank / (H - L)
        else:
            rank = H - 1
            if rank <= 1:
                hit1 += 1
            if rank <= 3:
                hit3 += 1
            if rank <= 10:
                hit10 += 1
            mr += rank
            mrr += 1.0 / rank

    hit1 /= len(ranks)
    hit3 /= len(ranks)
    hit10 /= len(ranks)
    mr /= len(ranks)
    mrr /= len(ranks)

    logger.info('Data : {}'.format(len(query2LH)))
    logger.info('Hit1 : {:.6f}'.format(hit1))
    logger.info('Hit3 : {:.6f}'.format(hit3))
    logger.info('Hit10: {:.6f}'.format(hit10))
    logger.info('MR   : {:.6f}'.format(mr))
    logger.info('MRR  : {:.6f}'.format(mrr))

    return mrr



def calc_rule_mrr2(model, valid_loader, test_set,model1 , logger=None):
    concat_logits = []
    concat_all_h = []
    concat_all_r = []
    concat_all_t = []
    concat_flag = []
    concat_mask = []

    for batch in tqdm(valid_loader):
        all_h, all_r, all_t, flag = batch
        all_h = all_h.squeeze(0)
        all_r = all_r.squeeze(0)
        all_t = all_t.squeeze(0)
        flag = flag.squeeze(0)

        all_h = all_h.cuda()
        all_r = all_r.cuda()
        all_t = all_t.cuda()
        flag = flag.cuda()

        logits, mask = model.cal_rule_score(all_h, all_r, None,model1 )

        concat_logits.append(logits)
        concat_all_h.append(all_h)
        concat_all_r.append(all_r)
        concat_all_t.append(all_t)
        concat_flag.append(flag)
        concat_mask.append(mask)

    concat_logits = torch.cat(concat_logits, dim=0)
    concat_all_h = torch.cat(concat_all_h, dim=0)
    concat_all_r = torch.cat(concat_all_r, dim=0)
    concat_all_t = torch.cat(concat_all_t, dim=0)
    concat_flag = torch.cat(concat_flag, dim=0)
    concat_mask = torch.cat(concat_mask, dim=0)

    ranks = []
    for k in range(concat_all_t.size(0)):
        h = concat_all_h[k]
        r = concat_all_r[k]
        t = concat_all_t[k]
        if concat_mask[k, t].item() == True:
            val = concat_logits[k, t]
            L = (concat_logits[k][concat_flag[k]] > val).sum().item() + 1
            H = (concat_logits[k][concat_flag[k]] >= val).sum().item() + 2
        else:
            L = 1
            H = test_set.graph.entity_size + 1
        ranks += [[h, r, t, L, H]]
    ranks = torch.tensor(ranks, dtype=torch.long).cuda()

    query2LH = dict()
    for h, r, t, L, H in ranks.data.cpu().numpy().tolist():
        query2LH[(h, r, t)] = (L, H)

    hit1, hit3, hit10, mr, mrr = 0.0, 0.0, 0.0, 0.0, 0.0
    expectation = True
    for (L, H) in query2LH.values():
        if expectation:
            for rank in range(L, H):
                if rank <= 1:
                    hit1 += 1.0 / (H - L)
                if rank <= 3:
                    hit3 += 1.0 / (H - L)
                if rank <= 10:
                    hit10 += 1.0 / (H - L)
                mr += rank / (H - L)
                mrr += 1.0 / rank / (H - L)
        else:
            rank = H - 1
            if rank <= 1:
                hit1 += 1
            if rank <= 3:
                hit3 += 1
            if rank <= 10:
                hit10 += 1
            mr += rank
            mrr += 1.0 / rank

    hit1 /= len(ranks)
    hit3 /= len(ranks)
    hit10 /= len(ranks)
    mr /= len(ranks)
    mrr /= len(ranks)

    logger.info('Data : {}'.format(len(query2LH)))
    logger.info('Hit1 : {:.6f}'.format(hit1))
    logger.info('Hit3 : {:.6f}'.format(hit3))
    logger.info('Hit10: {:.6f}'.format(hit10))
    logger.info('MR   : {:.6f}'.format(mr))
    logger.info('MRR  : {:.6f}'.format(mrr))
    return mrr


def calc_rule_mrr1(args,model, model1, rules, rules_mask, IM, valid_loader, test_set, logger=None):
    concat_logits = []
    concat_all_h = []
    concat_all_r = []
    concat_all_t = []
    concat_flag = []
    concat_mask = []

    for batch in tqdm(valid_loader):
        all_h, all_r, all_t, flag = batch
        all_h = all_h.squeeze(0)
        all_r = all_r.squeeze(0)
        all_t = all_t.squeeze(0)
        flag = flag.squeeze(0)

        all_h = all_h.cuda()
        all_r = all_r.cuda()
        all_t = all_t.cuda()
        flag = flag.cuda()

        logits, mask = model.cal_rule_score(all_h, all_r, None,model1)

        all_h_1 = all_h.unsqueeze(1)
        all_r_1 = all_r.unsqueeze(1)
        all_t_1 = all_t.unsqueeze(1)
        edges = torch.cat((all_h_1, all_r_1, all_t_1), dim=1).cuda()
        rules_mask = rules_mask.cuda()
        IM = IM.cuda()
        KGE_score = model1.cal_score(edges, rules, rules_mask, IM)

        logits = args.alpha * logits + args.beta * KGE_score

        concat_logits.append(logits)
        concat_all_h.append(all_h)
        concat_all_r.append(all_r)
        concat_all_t.append(all_t)
        concat_flag.append(flag)
        concat_mask.append(mask)

    concat_logits = torch.cat(concat_logits, dim=0)
    concat_all_h = torch.cat(concat_all_h, dim=0)
    concat_all_r = torch.cat(concat_all_r, dim=0)
    concat_all_t = torch.cat(concat_all_t, dim=0)
    concat_flag = torch.cat(concat_flag, dim=0)
    concat_mask = torch.cat(concat_mask, dim=0)

    ranks = []
    for k in range(concat_all_t.size(0)):
        h = concat_all_h[k]
        r = concat_all_r[k]
        t = concat_all_t[k]
        if concat_mask[k, t].item() == True:
            val = concat_logits[k, t]
            L = (concat_logits[k][concat_flag[k]] > val).sum().item() + 1
            H = (concat_logits[k][concat_flag[k]] >= val).sum().item() + 2
        else:
            L = 1
            H = test_set.graph.entity_size + 1
        ranks += [[h, r, t, L, H]]
    ranks = torch.tensor(ranks, dtype=torch.long).cuda()

    query2LH = dict()
    for h, r, t, L, H in ranks.data.cpu().numpy().tolist():
        query2LH[(h, r, t)] = (L, H)

    hit1, hit3, hit10, mr, mrr = 0.0, 0.0, 0.0, 0.0, 0.0
    expectation = True
    for (L, H) in query2LH.values():
        if expectation:
            for rank in range(L, H):
                if rank <= 1:
                    hit1 += 1.0 / (H - L)
                if rank <= 3:
                    hit3 += 1.0 / (H - L)
                if rank <= 10:
                    hit10 += 1.0 / (H - L)
                mr += rank / (H - L)
                mrr += 1.0 / rank / (H - L)
        else:
            rank = H - 1
            if rank <= 1:
                hit1 += 1
            if rank <= 3:
                hit3 += 1
            if rank <= 10:
                hit10 += 1
            mr += rank
            mrr += 1.0 / rank

    hit1 /= len(ranks)
    hit3 /= len(ranks)
    hit10 /= len(ranks)
    mr /= len(ranks)
    mrr /= len(ranks)

    logger.info('Data : {}'.format(len(query2LH)))
    logger.info('Hit1 : {:.6f}'.format(hit1))
    logger.info('Hit3 : {:.6f}'.format(hit3))
    logger.info('Hit10: {:.6f}'.format(hit10))
    logger.info('MR   : {:.6f}'.format(mr))
    logger.info('MRR  : {:.6f}'.format(mrr))
    return mrr


def read_rules(path):
    """
    read rule from file
    :return:
    list [rule_id, rule_head, rule_body]
    """
    rule_path = path + '/mined_rules.txt'
    rules = list()
    idx = 0
    with open(rule_path, 'r', encoding='utf-8') as f:
        for line in f:
            rule = line.strip().split()
            if len(rule) <= 1:
                continue
            rule = [idx] + [int(_) for _ in rule]
            idx += 1
            rules.append(rule)
    return rules
