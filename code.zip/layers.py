import torch
import torch.nn as nn
import torch.nn.functional as F


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dims, short_cut=False, batch_norm=False, activation="relu", dropout=0):
        super(MLP, self).__init__()

        self.dims = [input_dim] + hidden_dims
        self.short_cut = short_cut

        if isinstance(activation, str):
            self.activation = getattr(F, activation)
        else:
            self.activation = activation
        if dropout:
            self.dropout = nn.Dropout(dropout)
        else:
            self.dropout = None

        self.layers = nn.ModuleList()
        for i in range(len(self.dims) - 1):
            self.layers.append(nn.Linear(self.dims[i], self.dims[i + 1]))
        if batch_norm:
            self.batch_norms = nn.ModuleList()
            for i in range(len(self.dims) - 2):
                self.batch_norms.append(nn.BatchNorm1d(self.dims[i + 1]))
        else:
            self.batch_norms = None

    def forward(self, input):
        layer_input = input

        for i, layer in enumerate(self.layers):
            hidden = layer(layer_input)
            if i < len(self.layers) - 1:
                if self.batch_norms:
                    x = hidden.flatten(0, -2)
                    hidden = self.batch_norms[i](x).view_as(hidden)
                hidden = self.activation(hidden)
                if self.dropout:
                    hidden = self.dropout(hidden)
            if self.short_cut and hidden.shape == layer_input.shape:
                hidden = hidden + layer_input
            layer_input = hidden

        return hidden



class FuncToNodeSum_StructContextFusion(nn.Module):
    def __init__(self, entity_dim, rule_dim):
        super().__init__()
        self.entity_dim = entity_dim
        self.rule_dim = rule_dim

        self.context_proj = nn.Linear(entity_dim * 2, rule_dim)
        self.rule_proj = nn.Linear(rule_dim, rule_dim)
        self.attn_proj = nn.Linear(rule_dim, 1)
        self.rule_score = nn.Linear(rule_dim, 1)

        self.output_layer = nn.Sequential(
            nn.LayerNorm(rule_dim),
            nn.ReLU()
        )

        self.mha = nn.MultiheadAttention(embed_dim=rule_dim, num_heads=4, batch_first=False)
    def forward(self, A_fn, h_emb, r_emb, rule_emb, mlp_rule_feature):
        """
        A_fn: [R, N]
        h_emb, r_emb: [B, D]
        rule_emb: [R, D]
        mlp_rule_feature: [R, D]
        """
        device = h_emb.device
        D, R, N, B = self.rule_dim, rule_emb.size(0), A_fn.size(1), h_emb.size(0)

        # === 构造上下文表示 ===
        context = self.context_proj(torch.cat([h_emb, r_emb], dim=-1))  # [B, D]
        context = F.relu(context)
        context_vec = context.mean(dim=0, keepdim=True)  # [1, D]

        # === 语义注意力优化版（去除 [N, R, D]）===
        rule_keys = self.rule_proj(rule_emb)             # [R, D]
        # attn_logits = (context_vec @ rule_keys.T).squeeze(0)  # [R]
        # attn_weights = F.softmax(attn_logits, dim=-1)    # [R]
        # semantic_fused = torch.sum(attn_weights.unsqueeze(-1) * mlp_rule_feature, dim=0, keepdim=True)  # [1, D]
        # semantic_fused = semantic_fused.expand(N, -1)     # [N, D]
        # Q: context_vec （1 个 token）
        Q = context_vec.unsqueeze(0)  # [1, 1, D]
        # K,V: rule_keys （R 个 token）
        K = rule_keys.unsqueeze(1)  # [R, 1, D]
        V = mlp_rule_feature.unsqueeze(1)  # [R, 1, D]
        semantic_fused, attn_map = self.mha(Q, K, V)  # attn_map: [1, 1, R]
        semantic_fused = semantic_fused.squeeze(0)

        # === 结构融合部分（可带规则置信度）===
        rule_weights = torch.sigmoid(self.rule_score(rule_emb)).squeeze(-1)  # [R]
        A_weighted = A_fn * rule_weights.unsqueeze(1)                        # [R, N]
        struct_fused = A_weighted.T @ mlp_rule_feature                       # [N, D]

        # === 融合结构 + 语义 ===
        output = struct_fused + 3 * semantic_fused
        return self.output_layer(output)
