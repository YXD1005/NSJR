from torch.nn.init import xavier_normal_
from utils import get_param
import torch
import numpy as np, torch.nn as nn, torch.nn.functional as F
import dgl.function as fn
import dgl
class GlobalLayer(nn.Module):
    def __init__(self, h_dim):
        super().__init__()
        self.s_dim = 512
        self.s_w = get_param(h_dim, self.s_dim)
        self.fc_R = nn.Linear(self.s_dim, h_dim)

    def forward(self, Ht, ent_emb):
        De_i = 1 / Ht.sum(0)
        Dv_i = 1 / Ht.sum(1)
        De_i[torch.isinf(De_i)] = 0.0
        Dv_i[torch.isinf(Dv_i)] = 0.0
        set_embs = (Ht.t() @ ent_emb) * De_i[:, None] @ self.s_w
        gemb = (Ht @ set_embs) * Dv_i[:, None]
        gemb = F.relu(self.fc_R(gemb))
        return gemb

    def forward(self, Ht, ent_emb):
        De_i = 1 / Ht.sum(0)
        Dv_i = 1 / Ht.sum(1)
        De_i[torch.isinf(De_i)] = 0.0
        Dv_i[torch.isinf(Dv_i)] = 0.0
        set_embs = (Ht.t() @ ent_emb) * De_i[:, None] @ self.s_w
        gemb = (Ht @ set_embs) * Dv_i[:, None]
        gemb = F.relu(self.fc_R(gemb))
        return gemb


class CompLayer(nn.Module):  # triple SE layer
    def __init__(self, h_dim):
        super().__init__()

        self.comp_op = "mul"
        self.neigh_w = get_param(h_dim, h_dim)
        self.act = nn.Tanh()
        self.bn = torch.nn.BatchNorm1d(h_dim)
        self.ent_drop = nn.Dropout(0.2)
        self.rel_drop = nn.Dropout(0.2)

    def forward(self, kg, ent_emb, rel_emb):
        ent_emb, rel_emb = self.ent_drop(ent_emb), self.rel_drop(rel_emb)
        with kg.local_scope():
            kg.ndata['emb'] = ent_emb
            rel_id = kg.edata['rel_id']
            kg.edata['emb'] = rel_emb[rel_id]
            # neihgbor entity and relation composition
            kg.apply_edges(fn.u_mul_e('emb', 'emb', 'comp_emb'))

            # attention
            kg.apply_edges(fn.e_dot_v('comp_emb', 'emb', 'norm'))  # (n_edge, 1)
            kg.edata['norm'] = dgl.ops.edge_softmax(kg, kg.edata['norm'])
            # agg
            kg.edata['comp_emb'] = kg.edata['comp_emb'] * kg.edata['norm']
            kg.update_all(fn.copy_e('comp_emb', 'm'), fn.sum('m', 'neigh'))

            neigh_ent_emb = kg.ndata['neigh']

            neigh_ent_emb = neigh_ent_emb.mm(self.neigh_w)

            if callable(self.bn):
                neigh_ent_emb = self.bn(neigh_ent_emb)

            neigh_ent_emb = self.act(neigh_ent_emb)

        return neigh_ent_emb


class NodeLayer(nn.Module):   # # entity SE layer
    def __init__(self, h_dim):
        super().__init__()
        self.neigh_w = get_param(h_dim, h_dim)
        self.act = nn.Tanh()
        self.bn = torch.nn.BatchNorm1d(h_dim)
        self.ent_drop = nn.Dropout(0.2)
        self.rel_drop = nn.Dropout(0.2)

    def forward(self, kg, ent_emb):
        ent_emb = self.ent_drop(ent_emb)
        with kg.local_scope():
            kg.ndata['emb'] = ent_emb

            # attention
            kg.apply_edges(fn.u_dot_v('emb', 'emb', 'norm'))  # (n_edge, 1)
            kg.edata['norm'] = dgl.ops.edge_softmax(kg, kg.edata['norm'])

            # agg
            kg.update_all(fn.u_mul_e('emb', 'norm', 'm'), fn.sum('m', 'neigh'))
            neigh_ent_emb = kg.ndata['neigh']

            neigh_ent_emb = neigh_ent_emb.mm(self.neigh_w)

            if callable(self.bn):
                neigh_ent_emb = self.bn(neigh_ent_emb)

            neigh_ent_emb = self.act(neigh_ent_emb)

        return neigh_ent_emb


class EdgeLayer(nn.Module):   # relation SE layer
    def __init__(self, h_dim):
        super().__init__()

        self.ent_drop = nn.Dropout(0.2)
        self.rel_drop = nn.Dropout(0.2)
        self.act = nn.Tanh()
        self.bn = torch.nn.BatchNorm1d(h_dim)

        self.neigh_w = get_param(h_dim, h_dim)
    def forward(self, kg, ent_emb, rel_emb):
        ent_emb, rel_emb = self.ent_drop(ent_emb), self.rel_drop(rel_emb)
        with kg.local_scope():
            kg.ndata['emb'] = ent_emb
            rel_id = kg.edata['rel_id']
            kg.edata['emb'] = rel_emb[rel_id]

            # attention
            kg.apply_edges(fn.e_dot_v('emb', 'emb', 'norm'))  # (n_edge, 1)
            kg.edata['norm'] = dgl.ops.edge_softmax(kg, kg.edata['norm'])

            # agg
            kg.edata['emb'] = kg.edata['emb'] * kg.edata['norm']
            kg.update_all(fn.copy_e('emb', 'm'), fn.sum('m', 'neigh'))

            neigh_ent_emb = kg.ndata['neigh']

            neigh_ent_emb = neigh_ent_emb.mm(self.neigh_w)

            if callable(self.bn):
                neigh_ent_emb = self.bn(neigh_ent_emb)

            neigh_ent_emb = self.act(neigh_ent_emb)

        return neigh_ent_emb