import argparse, time, torch, logging, os
from datetime import datetime
from utils import get_mappings, get_main, setup_logger, read_rules, load_config, set_seed, construct_kg
from data import KnowledgeGraph, TrainDataset, ValidDataset, TestDataset, RuleDataset
from model import RENR, CASR
from trainer import PreTrainer, GroundTrainer
import numpy as np


def partitioning(train_data, args):
    n_samples = train_data.shape[0] // 2
    batch_size = args.batch_size // 2
    packed_train_data = [
        np.vstack(
            (train_data[i * batch_size:min((i + 1) * batch_size, n_samples)],
             train_data[i * batch_size + n_samples:min((i + 1) * batch_size, n_samples) + n_samples])
        )
        for i in range(int(np.ceil(n_samples / batch_size)))
    ]
    return packed_train_data


def main(args):
    set_seed(args.seed)
    exec_name = datetime.today().strftime('%Y-%m-%d-%H-%M') + '-' + args.dataset
    os.makedirs('./log', exist_ok=True)
    os.makedirs('./cache', exist_ok=True)
    log_file_path = './log/' + exec_name + '.log'
    logger = setup_logger(name=exec_name, level=logging.INFO, log_file=log_file_path)
    logger.info(args)
    # load graph data

    names2ids, rels2ids = get_mappings(args.data_path)
    num_nodes = len(names2ids.keys())
    num_rels = len(rels2ids.keys())
    graph = KnowledgeGraph(args.data_path)
    train_set = TrainDataset(graph, args.r_batch_size)
    valid_set = ValidDataset(graph, args.r_batch_size)
    test_set = TestDataset(graph, args.r_batch_size)
    rules = read_rules(args.data_path)
    ruleset = RuleDataset(args, rules, num_nodes, num_rels)

    train_data = get_main(
        args.data_path,
        'train.txt',
        names2ids,
        rels2ids,
        add_inverse=True
    )

    train_data1 = partitioning(train_data['triples'], args)
    #

    kg, Ht = construct_kg(train_data, num_nodes, num_rels)

    model_sa = RENR(
        args,
        graph,
        kg,
        Ht,
        num_nodes,
        num_rels,
        args.n_layers,
        args.d_embed,
        args.d_k,
        args.d_v,
        args.d_model,
        args.d_inner,
        args.num_heads,
        args.h_dim,
        **{'dr_enc': args.dr_enc,
           'dr_pff': args.dr_pff,
           'dr_sdp': args.dr_sdp,
           'dr_mha': args.dr_mha,
           'decoder': args.decoder}
    )

    pre_trainer = PreTrainer(
        model=model_sa,
        train_set=train_data1,
        valid_set=valid_set,
        test_set=test_set,
        ruleset=ruleset
    )
    pre_trainer.train(args, logger, names2ids, rels2ids, args.sa_model)
    checkpoint = torch.load(args.sa_model)
    pre_trainer.test(logger, checkpoint)
    model_rule = CASR(args, graph, num_nodes, num_rels, rules)
    ground_trainer = GroundTrainer(
        model=model_rule,
        model1=model_sa,
        train_set=train_set,
        valid_set=valid_set,
        test_set=test_set,
        ruleset=ruleset
    )

    ground_trainer.train(args, logger, args.rule_model)
    checkpoint1 = torch.load(args.rule_model)
    ground_trainer.test(args, logger, checkpoint1, checkpoint)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='RNNLogic',
        usage='train.py [<args>] [-h | --help]'
    )
    parser.add_argument("--gpu", type=int, default=0,
                        help="gpu")
    parser.add_argument("--lr", type=float, default=0.001,
                        help="learning rate")
    parser.add_argument("--lr_decay", type=float, default=0.995,
                        help="learning rate decay rate")
    parser.add_argument("--lr_step_decay", type=int, default=2,
                        help="learning rate decay at each scheduled step")
    parser.add_argument("--n_layers", type=int, default=1,
                        help="number of encoder layers")
    parser.add_argument("--n_epochs", type=int, default=100,
                        help="number of minimum training epochs")
    parser.add_argument("--dataset", type=str, default='umls',
                        help="dataset to use: FB15k-237 or wn18rr or umls or YAGO3-10")
    parser.add_argument("--data_path", type=str, default='data/umls')
    parser.add_argument("--batch_size", type=int, default=1024)
    parser.add_argument("--start_test_at", type=int, default=500)
    parser.add_argument("--num_heads", type=int, default=64)
    parser.add_argument('--d_k', default=32, type=int)
    parser.add_argument('--d_v', default=50, type=int)
    parser.add_argument('--d_model', default=100, type=int)
    parser.add_argument('--d_embed', default=100, type=int)
    parser.add_argument('--d_inner', default=2048, type=int)
    parser.add_argument('--label_smoothing', default=0.1, type=float)
    parser.add_argument('--dr_enc', default=0.4, type=float)
    parser.add_argument('--dr_pff', default=0.2, type=float)
    parser.add_argument('--dr_sdp', default=0.1, type=float)
    parser.add_argument('--dr_mha', default=0.3, type=float)
    parser.add_argument('--decay-until', default=1050, type=int)
    parser.add_argument('--decoder', default='twomult', type=str)
    parser.add_argument('--num_encoder', default=2, type=int)
    parser.add_argument('--h_dim', default=100, type=int)
    parser.add_argument('--mlp_rule_dim', default=16, type=int)
    parser.add_argument('--rule_hidden_dim', default=1024, type=int)
    parser.add_argument('--rule_dim', default=1024, type=int)
    parser.add_argument('--rule_len', default=5, type=int)
    parser.add_argument('--comp_op', default='mul', type=str)
    parser.add_argument('--rule_drop', default=0.1, type=int)
    parser.add_argument('--smoothing', default=0.2, type=int)
    parser.add_argument('--g_lr', default=0.005, type=int)
    parser.add_argument('--weight_decay', default=0, type=int)
    parser.add_argument('--num_iters', default=20, type=int)
    parser.add_argument('--topk', default=14541, type=int)
    parser.add_argument('--r_batch_size', default=16, type=int)
    parser.add_argument('--batch_per_epoch', default=1000000, type=int)
    parser.add_argument('--save_path', default="fb", type=str)
    parser.add_argument('--alpha', default=1, type=int)
    parser.add_argument('--beta', default=2, type=int)
    parser.add_argument('--seed', default=2411, type=int)
    parser.add_argument('--print_every', default=1000, type=int)
    parser.add_argument('--kg_n_layer', default=1, type=int)
    parser.add_argument('--sa_model', default="cache/fb/best_CASR.pth", type=str)
    parser.add_argument('--rule_model', default="cache/fb/best_RENR.pth", type=str)
    args = parser.parse_args()
    main(args)
